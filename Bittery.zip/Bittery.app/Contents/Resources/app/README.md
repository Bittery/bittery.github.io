# Bittery :tada:
### A battery saver
So you can spend more time looking at :cat2: pics
_____
Icons made by [Situ Herrera][0] from [www.flaticon.com][1] is licensed by [CC 3.0 BY][2]

[0]: https://www.flaticon.com/authors/situ-herrera "Situ Herrera"
[1]: https://www.flaticon.com/ "Flaticon"
[2]: http://creativecommons.org/licenses/by/3.0/ "Creative Commons BY 3.0"